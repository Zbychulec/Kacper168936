﻿#include <iostream>

using namespace std;

int main() {
    cout << "Prosty Kalkulator" << endl;
    cout << "Wybierz operację:" << endl;
    cout << "1. Dodawanie" << endl;
    cout << "2. Odejmowanie" << endl;
    cout << "3. Mnożenie" << endl;
    cout << "4. Dzielenie" << endl;
    cout << "Kacper Zbytniewski 168936" << endl;


    int operacja;
    cout << "Podaj numer operacji: ";
    cin >> operacja;

    double liczba1, liczba2, wynik;
    cout << "Podaj pierwszą liczbę: ";
    cin >> liczba1;

    cout << "Podaj drugą liczbę: ";
    cin >> liczba2;

    bool poprawnaOperacja = true;

    switch (operacja) {
    case 1:
        wynik = liczba1 + liczba2;
        break;
    case 2:
        wynik = liczba1 - liczba2;
        break;
    case 3:
        wynik = liczba1 * liczba2;
        break;
    case 4:
        if (liczba2 != 0) {
            wynik = liczba1 / liczba2;
        }
        else {
            cout << "Błąd: Dzielenie przez zero." << endl;
            poprawnaOperacja = false;
        }
        break;
    default:
        cout << "Nieprawidłowa operacja." << endl;
        poprawnaOperacja = false;
    }

    if (poprawnaOperacja) {
        cout << "Wynik: " << wynik << endl;
    }

    return 0;


}
